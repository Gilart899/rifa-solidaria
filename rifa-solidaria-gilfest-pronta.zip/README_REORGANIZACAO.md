# Rifa Solidária — GilFest

Pacote preparado a partir do projeto enviado pelo usuário.

A pasta `functions/` contém a base das Cloud Functions para a raspadinha segura.
O processamento final dos prêmios ainda deve ser publicado antes de liberar a raspadinha em produção.
