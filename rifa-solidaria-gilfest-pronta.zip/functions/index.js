// ==========================================================
// RIFA SOLIDÁRIA — GILFEST
// CLOUD FUNCTIONS — BASE SEGURA DA RASPADINHA
// ==========================================================

const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const crypto = require("crypto");

initializeApp();
const db = getDatabase();

function normalizarNumero(numero) {
  const valor = String(numero ?? "").trim();
  if (!/^\d{1,3}$/.test(valor)) return null;
  const normalizado = valor.padStart(3, "0");
  const inteiro = Number(normalizado);
  return inteiro >= 0 && inteiro <= 999 ? normalizado : null;
}

exports.criarJogadaRaspadinha = onCall(
  { region: "southamerica-east1" },
  async (request) => {
    if (!request.auth) {
      throw new HttpsError("unauthenticated", "É necessário estar autenticado.");
    }

    const participanteId = request.auth.uid;
    const numeroRifa = normalizarNumero(request.data?.numeroRifa);

    if (!numeroRifa) {
      throw new HttpsError("invalid-argument", "Número da rifa inválido.");
    }

    const numeroSnapshot = await db.ref(`rifa/numeros/${numeroRifa}`).once("value");
    if (!numeroSnapshot.exists()) {
      throw new HttpsError("not-found", "Número da rifa não encontrado.");
    }

    const numero = numeroSnapshot.val();

    if (numero.status !== "vendido" || numero.pagamento !== true) {
      throw new HttpsError(
        "failed-precondition",
        "A raspadinha só pode ser liberada após a confirmação do pagamento."
      );
    }

    if (numero.participanteId && numero.participanteId !== participanteId) {
      throw new HttpsError("permission-denied", "Este número pertence a outro participante.");
    }

    const jogadasSnapshot = await db
      .ref("rifa/raspadinha/jogadas")
      .orderByChild("participanteId")
      .equalTo(participanteId)
      .once("value");

    const jogadas = jogadasSnapshot.val() || {};

    for (const [jogadaId, jogada] of Object.entries(jogadas)) {
      if (
        jogada.numeroRifa === numeroRifa &&
        jogada.liberada === true &&
        jogada.utilizada === false
      ) {
        return { sucesso: true, jogadaId, mensagem: "Existe uma raspadinha liberada." };
      }
    }

    const utilizadas = Object.values(jogadas).filter(
      (jogada) => jogada.numeroRifa === numeroRifa && jogada.utilizada === true
    ).length;

    if (utilizadas >= 2) {
      throw new HttpsError(
        "failed-precondition",
        "Esta participação já utilizou todas as raspadinhas disponíveis."
      );
    }

    const jogadaId = crypto.randomUUID();

    await db.ref(`rifa/raspadinha/jogadas/${jogadaId}`).set({
      numeroRifa,
      participanteId,
      liberada: true,
      utilizada: false,
      resultado: null,
      premio: null,
      novaChance: false,
      dataCriacao: Date.now(),
      dataUtilizacao: null
    });

    return {
      sucesso: true,
      jogadaId,
      numeroRifa,
      mensagem: "Raspadinha liberada com sucesso."
    };
  }
);
