import { CONFIG, formatarMoeda } from "./config.js";

const compra=JSON.parse(localStorage.getItem("rifaCompra")||"{}");
const $=id=>document.getElementById(id);
function preencher(){
  $("nomeCliente")&&( $("nomeCliente").textContent=compra.nome||"—");
  $("telefoneCliente")&&( $("telefoneCliente").textContent=compra.telefone||"—");
  $("numeroCliente")&&( $("numeroCliente").textContent=compra.numero||"—");
  $("valorCliente")&&( $("valorCliente").textContent=formatarMoeda(compra.valor??CONFIG.valorNumero));
  $("dataCliente")&&( $("dataCliente").textContent=new Date().toLocaleDateString("pt-BR"));
  if(window.QRCode&&$("qrPix")){new QRCode($("qrPix"),{text:CONFIG.pix.chave,width:180,height:180})}
}
async function gerar(){if(!window.jspdf){alert("Biblioteca PDF não carregada.");return}const {jsPDF}=window.jspdf;const pdf=new jsPDF();pdf.setFontSize(18);pdf.text("RIFA SOLIDÁRIA",20,25);pdf.setFontSize(12);pdf.text("Comprovante de Participação",20,35);pdf.text(`Nome: ${compra.nome||"---"}`,20,60);pdf.text(`Telefone: ${compra.telefone||"---"}`,20,70);pdf.text(`Número: ${compra.numero||"---"}`,20,80);pdf.text(`Valor: ${formatarMoeda(compra.valor??CONFIG.valorNumero)}`,20,90);pdf.text(`PIX: ${CONFIG.pix.chave}`,20,100);pdf.text(`Beneficiada: ${CONFIG.beneficiada}`,20,110);pdf.save("comprovante-rifa-solidaria.pdf")}
$("gerarPDF")?.addEventListener("click",gerar);$("voltar")?.addEventListener("click",()=>location.href="index.html");window.addEventListener("DOMContentLoaded",preencher);
