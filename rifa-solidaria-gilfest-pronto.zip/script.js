// ==========================================================
// SCRIPT PRINCIPAL — RIFA SOLIDÁRIA
// ==========================================================

import {
  CONFIG,
  formatarNumero,
  formatarMoeda,
  calcularContagem,
  criarLinkWhatsapp,
  criarMensagemReserva,
  numeroValido
} from "./config.js";
import { numerosRef, get, onValue } from "./firebase.js";
import { copiarTexto } from "./utils.js";

const $ = (id) => document.getElementById(id);
const state = { numero: null, status: null, slide: 0 };

function toast(mensagem) {
  const el = $("toast");
  if (!el) return;
  el.textContent = mensagem;
  el.classList.add("visivel");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove("visivel"), CONFIG.animacao.toast);
}

function preencherConfiguracao() {
  const titulo = $("titulo");
  const subtitulo = $("subtitulo");
  const premio = $("premio");
  const valor = $("valor");
  const data = $("dataSorteio");
  const pix = $("pixKey");

  if (titulo) titulo.textContent = CONFIG.titulo;
  if (subtitulo) subtitulo.textContent = CONFIG.subtitulo;
  if (premio) premio.textContent = CONFIG.premio;
  if (valor) valor.textContent = formatarMoeda(CONFIG.valorNumero);
  if (data) data.textContent = new Date(`${CONFIG.sorteio.data}T${CONFIG.sorteio.hora}:00`).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  if (pix) pix.value = CONFIG.pix.chave;

  const titular = document.querySelector("[data-pix-titular]");
  const banco = document.querySelector("[data-pix-banco]");
  if (titular) titular.textContent = CONFIG.pix.titular;
  if (banco) banco.textContent = CONFIG.pix.banco;
}

function iniciarCarrossel() {
  const slides = [...document.querySelectorAll(".slide")];
  if (!slides.length) return;

  const mostrar = (index) => {
    state.slide = (index + slides.length) % slides.length;
    slides.forEach((slide, i) => slide.classList.toggle("active", i === state.slide));
  };

  $("prevSlide")?.addEventListener("click", () => mostrar(state.slide - 1));
  $("nextSlide")?.addEventListener("click", () => mostrar(state.slide + 1));
  setInterval(() => mostrar(state.slide + 1), CONFIG.animacao.carrossel);
}

function atualizarContagem() {
  const c = calcularContagem();
  $("dias") && ($("dias").textContent = String(c.dias).padStart(2, "0"));
  $("horas") && ($("horas").textContent = String(c.horas).padStart(2, "0"));
  $("minutos") && ($("minutos").textContent = String(c.minutos).padStart(2, "0"));
  $("segundos") && ($("segundos").textContent = String(c.segundos).padStart(2, "0"));
}

async function pesquisarNumero() {
  const campo = $("buscarNumero");
  const resultado = $("resultadoBusca");
  if (!campo || !resultado) return;

  const valor = Number(campo.value);
  if (!numeroValido(valor)) {
    resultado.innerHTML = `<div class="resultado erro">Digite um número entre 000 e 999.</div>`;
    return;
  }

  const numero = formatarNumero(valor);
  resultado.innerHTML = `<div class="resultado carregando">Consultando ${numero}...</div>`;

  try {
    const snapshot = await get(numerosRef);
    const dados = snapshot.exists() ? snapshot.val()?.[numero] : null;
    state.numero = numero;
    state.status = dados?.status || CONFIG.status.DISPONIVEL;

    const indisponivel = state.status !== CONFIG.status.DISPONIVEL;
    resultado.innerHTML = `
      <div class="resultado ${indisponivel ? "indisponivel" : "disponivel"}">
        <strong>Número ${numero}</strong>
        <span>${indisponivel ? `🔴 ${state.status === "vendido" ? "Vendido" : "Reservado"}` : "🟢 Disponível"}</span>
        ${indisponivel ? "" : `<button type="button" class="btn btn-primary btn-mini" id="btnEscolherPesquisado">Escolher ${numero}</button>`}
      </div>`;

    $("btnEscolherPesquisado")?.addEventListener("click", () => {
      localStorage.setItem("numeroSelecionado", numero);
      window.location.href = `cartela.html?numero=${numero}`;
    });
  } catch (erro) {
    console.error(erro);
    resultado.innerHTML = `<div class="resultado erro">Não foi possível consultar o número agora.</div>`;
  }
}

function configurarAcoes() {
  $("btnBuscarNumero")?.addEventListener("click", pesquisarNumero);
  $("buscarNumero")?.addEventListener("keydown", (e) => e.key === "Enter" && pesquisarNumero());

  $("copiarPix")?.addEventListener("click", async () => {
    const ok = await copiarTexto(CONFIG.pix.chave);
    toast(ok ? "✅ Chave PIX copiada!" : "⚠️ Não foi possível copiar automaticamente.");
  });

  const whats = $("btnWhatsapp");
  if (whats) {
    whats.href = criarLinkWhatsapp(`Olá! Gostaria de participar da Rifa Solidária. Quero informações sobre os números disponíveis.`);
  }

  const comprovanteUrl = criarLinkWhatsapp(CONFIG.whatsapp.mensagemComprovante);
  [$("btnComprovante"), $("btnComprovante2")].filter(Boolean).forEach((el) => { el.href = comprovanteUrl; });

  const numeroSalvo = localStorage.getItem("numeroSelecionado");
  if (numeroSalvo && numeroValido(Number(numeroSalvo)) && $("numeroSelecionado")) {
    $("numeroSelecionado").textContent = formatarNumero(numeroSalvo);
  }
}

function iniciar() {
  preencherConfiguracao();
  iniciarCarrossel();
  atualizarContagem();
  setInterval(atualizarContagem, 1000);
  configurarAcoes();
  onValue(numerosRef, (snap) => {
    const salvo = localStorage.getItem("numeroSelecionado");
    const d = salvo && snap.exists() ? snap.val()?.[formatarNumero(salvo)] : null;
    const area = $("areaRaspadinha"), btn = $("btnRaspadinha");
    if (area && btn && d?.status === "vendido" && d.pagamentoConfirmado && d.raspadinhaLiberada && !d.raspadinhaUsada) { area.hidden = false; btn.href = `raspadinha.html?numero=${formatarNumero(salvo)}`; } else if (area) area.hidden = true;
  });
}

window.addEventListener("DOMContentLoaded", iniciar);
