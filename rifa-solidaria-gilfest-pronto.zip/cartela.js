import { CONFIG, formatarNumero, formatarMoeda, obterCartela, intervaloCartela, criarMensagemReserva, criarLinkWhatsapp } from "./config.js";
import { db, numerosRef, participantesRef, onValue, runTransaction, push, ref, set } from "./firebase.js";

const $ = (id) => document.getElementById(id);
const STATUS = {};
const selecionados = new Set();
let cartelaAtual = 1;

function toast(msg){const el=$("toast");if(!el)return;el.textContent=msg;el.classList.add("visivel");clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove("visivel"),3000)}
function reservadoExpirado(dados){return dados?.status === CONFIG.status.RESERVADO && dados.dataReserva && Date.now()-Number(dados.dataReserva) > CONFIG.reserva.tempoMinutos*60000}
function criarCartelas(){
  const container=$("containerCartelas"); if(!container)return; container.innerHTML="";
  for(let c=1;c<=CONFIG.totalCartelas;c++){
    const sec=document.createElement("section");sec.className=`cartela ${c===1?"ativa":""}`;sec.dataset.cartela=c;
    const {inicio,fim}=intervaloCartela(c);
    sec.innerHTML=`<div class="cartela-header"><h2>Cartela ${String(c).padStart(2,"0")}</h2><span>${formatarNumero(inicio)} — ${formatarNumero(fim)}</span></div><div class="gradeCartela"></div>`;
    const grade=sec.querySelector(".gradeCartela");
    for(let n=inicio;n<=fim;n++){const b=document.createElement("button");b.type="button";b.className="numero disponivel";b.textContent=formatarNumero(n);b.dataset.numero=formatarNumero(n);b.addEventListener("click",()=>selecionarNumero(b));grade.appendChild(b)}
    container.appendChild(sec);
  }
}
function atualizarNumeros(){document.querySelectorAll(".numero").forEach(b=>{const dados=STATUS[b.dataset.numero];b.classList.remove("disponivel","reservado","vendido","selecionado");if(!dados||reservadoExpirado(dados)||dados.status===CONFIG.status.DISPONIVEL)b.classList.add("disponivel");else b.classList.add(dados.status==="vendido"?"vendido":"reservado");if(selecionados.has(b.dataset.numero)&&b.classList.contains("disponivel"))b.classList.add("selecionado")})}
function carregarFirebase(){onValue(numerosRef,s=>{Object.keys(STATUS).forEach(k=>delete STATUS[k]);if(s.exists())Object.assign(STATUS,s.val());atualizarNumeros();verificarRaspadinha()})}
function verificarRaspadinha(){
  const salvo=localStorage.getItem("numeroSelecionado");
  const area=$("areaRaspadinha"),btn=$("btnRaspadinha");
  if(!area||!btn||!salvo)return;
  const numero=formatarNumero(salvo),d=STATUS[numero];
  if(d?.status==="vendido"&&d.pagamentoConfirmado&&d.raspadinhaLiberada&&!d.raspadinhaUsada){area.hidden=false;btn.href=`raspadinha.html?numero=${numero}`}else area.hidden=true;
}
function abrirCartela(c){cartelaAtual=Number(c);document.querySelectorAll(".cartela").forEach(x=>x.classList.toggle("ativa",Number(x.dataset.cartela)===cartelaAtual));document.querySelectorAll(".cartela-tab").forEach(x=>x.classList.toggle("ativo",Number(x.dataset.cartela)===cartelaAtual))}
function pesquisar(){const n=Number($("buscarNumero")?.value);if(!Number.isInteger(n)||n<0||n>=CONFIG.totalNumeros){toast("⚠️ Digite um número entre 000 e 999.");return}const numero=formatarNumero(n);abrirCartela(obterCartela(n));const b=document.querySelector(`[data-numero="${numero}"]`);b?.scrollIntoView({behavior:"smooth",block:"center"});b?.classList.add("destacado");setTimeout(()=>b?.classList.remove("destacado"),2500);$("resultadoBusca").innerHTML=`<div class="resultado"><strong>Número ${numero}</strong> — ${STATUS[numero]&&STATUS[numero].status!=="disponivel"&&!reservadoExpirado(STATUS[numero])?"🔴 indisponível":"🟢 disponível"}</div>`}
function selecionarNumero(botao){const numero=botao.dataset.numero;const dados=STATUS[numero];if(dados&&!reservadoExpirado(dados)&&dados.status!==CONFIG.status.DISPONIVEL){toast(dados.status==="vendido"?"🔴 Este número já foi vendido.":"🟠 Este número está reservado.");return}if(selecionados.has(numero))selecionados.delete(numero);else selecionados.add(numero);atualizarResumo();atualizarNumeros()}
function atualizarResumo(){const arr=[...selecionados].sort();$("quantidadeSelecionados").textContent=arr.length;$("valorSelecionado").textContent=formatarMoeda(arr.length*CONFIG.valorNumero);$("listaSelecionados").innerHTML=arr.map(n=>`<span class="itemSelecionado">${n}</span>`).join("");$("modalNumeros").textContent=arr.join(", ")||"—";$("modalValor").textContent=formatarMoeda(arr.length*CONFIG.valorNumero)}
function abrirModal(){if(!selecionados.size){toast("⚠️ Escolha pelo menos um número.");return}$("modalReserva").classList.add("ativo");atualizarResumo()}
function fecharModal(){$("modalReserva")?.classList.remove("ativo")}
async function confirmarReserva(){
  const nome=$("nomeParticipante").value.trim(),telefone=$("telefoneParticipante").value.trim();
  if(!nome||!telefone){toast("⚠️ Informe nome e WhatsApp.");return}
  const numeros=[...selecionados].sort();
  // Reserva atômica por número.
  const adquiridos=[];
  try{
    for(const numero of numeros){
      const numeroRef=ref(db,"numeros/"+numero);
      const resultado=await runTransaction(numeroRef,(atual)=>{
        if(atual&&!reservadoExpirado(atual)&&atual.status!==CONFIG.status.DISPONIVEL)return;
        return {status:"reservado",nome,telefone,dataReserva:Date.now(),pagamentoConfirmado:false,raspadinhaLiberada:false,raspadinhaUsada:false};
      });
      if(!resultado.committed){
        for(const reservado of adquiridos) await set(ref(db,"numeros/"+reservado),null);
        toast(`❌ O número ${numero} ficou indisponível. Nenhum número foi reservado.`);
        return;
      }
      adquiridos.push(numero);
    }
    await push(participantesRef,{nome,telefone,numeros,valor:numeros.length*CONFIG.valorNumero,dataReserva:Date.now(),status:"reservado"});
    localStorage.setItem("rifaCompra",JSON.stringify({nome,telefone,numero:numeros.join(", "),numeros,valor:numeros.length*CONFIG.valorNumero}));
    localStorage.setItem("numeroSelecionado",numeros[0]);
    fecharModal();selecionados.clear();atualizarResumo();
    const link=criarLinkWhatsapp(criarMensagemReserva(nome,telefone,numeros));
    window.open(link,"_blank","noopener");
    toast("✅ Reserva realizada! Agora envie o comprovante pelo WhatsApp.");
  }catch(erro){console.error(erro);toast("❌ Não foi possível concluir a reserva.")}
}
function iniciar(){
  criarCartelas();carregarFirebase();
  document.querySelectorAll(".cartela-tab").forEach(b=>b.addEventListener("click",()=>abrirCartela(b.dataset.cartela)));
  $("btnPesquisar")?.addEventListener("click",pesquisar);$("buscarNumero")?.addEventListener("keydown",e=>e.key==="Enter"&&pesquisar());
  $("btnReservar")?.addEventListener("click",abrirModal);$("btnLimpar")?.addEventListener("click",()=>{selecionados.clear();atualizarResumo();atualizarNumeros()});$("fecharModal")?.addEventListener("click",fecharModal);$("modalReserva")?.addEventListener("click",e=>{if(e.target.id==="modalReserva")fecharModal()});$("btnConfirmarReserva")?.addEventListener("click",confirmarReserva);
  const q=new URLSearchParams(location.search).get("numero");if(q&&Number.isInteger(Number(q))){$("buscarNumero").value=Number(q);setTimeout(pesquisar,100)}
  atualizarResumo();
}
window.addEventListener("DOMContentLoaded",iniciar);
