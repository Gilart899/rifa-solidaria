// ==========================================================
// CONFIGURAÇÃO CENTRAL — RIFA SOLIDÁRIA / GILFEST
// ==========================================================

export const CONFIG = Object.freeze({
  campanha: "Rifa Solidária",
  titulo: "🎟️ RIFA ENTRE AMIGOS",
  subtitulo: "💙 Em prol da realização dos exames de Dona Benedita",
  beneficiada: "Dona Bené",
  premio: "Geladeira Midea Frost Free",
  descricao: "Participe da Rifa Solidária e ajude Dona Bené na realização dos exames.",

  valorNumero: 10,
  moeda: "BRL",
  totalNumeros: 1000,
  totalCartelas: 10,
  numerosPorCartela: 100,

  sorteio: Object.freeze({
    data: "2026-12-30",
    hora: "20:00"
  }),

  pix: Object.freeze({
    titular: "Maria Josivania Claudino França",
    chave: "79988730207",
    banco: "Banco Neon"
  }),

  whatsapp: Object.freeze({
    numero: "5579988730207",
    mensagemReserva: "Olá! Gostaria de reservar os números {NUMEROS} da Rifa Solidária.\n\nNome: {NOME}\nWhatsApp: {TELEFONE}\n\nVou realizar o pagamento via PIX e enviar o comprovante.",
    mensagemComprovante: "Olá! Estou enviando o comprovante de pagamento da Rifa Solidária."
  }),

  status: Object.freeze({
    DISPONIVEL: "disponivel",
    RESERVADO: "reservado",
    VENDIDO: "vendido"
  }),

  raspadinha: Object.freeze({
    enabled: true,
    titulo: "Raspadinha da Amizade",
    mensagem: "Sua sorte pode mudar hoje!",
    premios: Object.freeze([
      "Liquidificador",
      "Ferro elétrico"
    ])
  }),

  reserva: Object.freeze({
    tempoMinutos: 30
  }),

  animacao: Object.freeze({
    carrossel: 5000,
    toast: 3000
  }),

  imagens: Object.freeze({
    logo: "img/1784636629590.png",
    beneficiada: "img/1783887880857.png",
    premio1: "img/IMG-20260722-WA0037.jpg",
    premio2: "img/IMG-20260722-WA0038.jpg",
    premio3: "img/IMG-20260722-WA0040.jpg",
    trevo: "img/trevo.png"
  })
});

export function formatarNumero(numero) {
  return String(Number(numero)).padStart(3, "0");
}

export function formatarMoeda(valor) {
  return Number(valor).toLocaleString("pt-BR", {
    style: "currency",
    currency: CONFIG.moeda
  });
}

export function obterCartela(numero) {
  const n = Number(numero);
  if (!Number.isInteger(n) || n < 0 || n >= CONFIG.totalNumeros) return null;
  return Math.floor(n / CONFIG.numerosPorCartela) + 1;
}

export function intervaloCartela(cartela) {
  const c = Number(cartela);
  const inicio = (c - 1) * CONFIG.numerosPorCartela;
  return { inicio, fim: inicio + CONFIG.numerosPorCartela - 1 };
}

export function numeroValido(numero) {
  const n = Number(numero);
  return Number.isInteger(n) && n >= 0 && n < CONFIG.totalNumeros;
}

export function dataSorteio() {
  return new Date(`${CONFIG.sorteio.data}T${CONFIG.sorteio.hora}:00`);
}

export function calcularContagem() {
  const diff = Math.max(0, dataSorteio().getTime() - Date.now());
  return {
    dias: Math.floor(diff / 86400000),
    horas: Math.floor((diff % 86400000) / 3600000),
    minutos: Math.floor((diff % 3600000) / 60000),
    segundos: Math.floor((diff % 60000) / 1000)
  };
}

export function criarLinkWhatsapp(texto = "") {
  return `https://wa.me/${CONFIG.whatsapp.numero}?text=${encodeURIComponent(texto)}`;
}

export function criarMensagemReserva(nome, telefone, numeros) {
  return CONFIG.whatsapp.mensagemReserva
    .replace("{NUMEROS}", numeros.map(formatarNumero).join(", "))
    .replace("{NOME}", nome || "")
    .replace("{TELEFONE}", telefone || "");
}
