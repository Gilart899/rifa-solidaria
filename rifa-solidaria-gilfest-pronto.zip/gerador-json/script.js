const form=document.getElementById('gerador');
form?.addEventListener('submit',e=>{e.preventDefault();const n=Number(document.getElementById('quantidade').value||1000);const out={numeros:{}};for(let i=0;i<n;i++)out.numeros[String(i).padStart(3,'0')]={status:'disponivel'};const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='numeros-rifa.json';a.click();URL.revokeObjectURL(a.href)});
document.getElementById('btnGerar')?.addEventListener('click',()=>form?.requestSubmit());
