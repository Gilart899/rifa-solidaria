import { CONFIG, formatarNumero, formatarMoeda, criarLinkWhatsapp } from "./config.js";

export { formatarNumero, formatarMoeda, criarLinkWhatsapp };

export function obterCartela(numero) {
  const n = Number(numero);
  if (!Number.isInteger(n) || n < 0 || n >= CONFIG.totalNumeros) return null;
  return Math.floor(n / CONFIG.numerosPorCartela) + 1;
}

export function intervaloCartela(cartela) {
  const inicio = (Number(cartela) - 1) * CONFIG.numerosPorCartela;
  return { inicio, fim: inicio + CONFIG.numerosPorCartela - 1 };
}

export function calcularValor(qtd) {
  return Number(qtd) * CONFIG.valorNumero;
}

export async function copiarTexto(texto) {
  try {
    await navigator.clipboard.writeText(texto);
    return true;
  } catch {
    return false;
  }
}

export function formatarData(data) {
  return new Date(data).toLocaleDateString("pt-BR");
}

export function formatarHora(data) {
  return new Date(data).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}
